// Tip: 1000 ms = 1 second.

var myVar = setInterval(myTimer, 100000);

function myTimer() {

  $("#div1").fadeOut(2000, function() {
    $(this).fadeIn(2000);

  });

}

var myVar2 = setInterval(myTimer2, 200000);

function myTimer2() {

  $("#div2").fadeOut(2000, function() {
    $(this).fadeIn(2000);

  });

}

var myVar3 = setInterval(myTimer3, 300000);

function myTimer3() {

  $("#div3").fadeOut(2000, function() {
    $(this).fadeIn(2000);

  });

}

var myVar4 = setInterval(myTimer4, 400000);

function myTimer4() {

  $("#div4").fadeOut(2000, function() {
    $(this).fadeIn(2000);

  });

}

var myVar5 = setInterval(myTimer5, 50000);

function myTimer5() {

  $("#div5").fadeOut(2000, function() {
    $(this).fadeIn(2000);
  });

}

var myVar6 = setInterval(myTimer6, 60000);

function myTimer6() {

  $("#div6").fadeOut(2000, function() {
    $(this).fadeIn(2000);
  });

}

var myVar7 = setInterval(myTimer7, 7000);

function myTimer7() {

  $("#div7").fadeOut(20000, function() {
    $(this).fadeIn(2000);
  });

}

var myVar8 = setInterval(myTimer8, 8000);

function myTimer8() {

  $("#div8").fadeOut(2000, function() {
    $(this).fadeIn(2000);
  });

}

var myVar9 = setInterval(myTimer9, 9000);

function myTimer9() {

  $("#div9").fadeOut(2000, function() {
    $(this).fadeIn(2000);
  });

}

